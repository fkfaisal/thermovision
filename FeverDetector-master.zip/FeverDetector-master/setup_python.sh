#!/usr/bin/env bash
#sudo chmod 775 setup_python.sh
#./setup_python.sh

pip3 install PyQt5 opencv-python psutil h5py tifffile

